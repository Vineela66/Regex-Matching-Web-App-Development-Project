from flask import Flask, render_template, request
import re

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    matches = None
    test_string = ""
    regex_pattern = ""

    if request.method == "POST":
        test_string = request.form["test_string"]
        regex_pattern = request.form["regex_pattern"]

        try:
            matches = re.findall(regex_pattern, test_string)
        except re.error:
            matches = ["Invalid Regex Pattern"]

    return render_template("index.html", matches=matches, test_string=test_string, regex_pattern=regex_pattern)


@app.route("/validate_email", methods=["GET", "POST"])
def validate_email():
    email = ""
    is_valid = None
    pattern = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"

    if request.method == "POST":
        email = request.form["email"]
        is_valid = bool(re.match(pattern, email))

    return render_template("validate_email.html", email=email, is_valid=is_valid)

if __name__ == "__main__":
    app.run(debug=True)











